import UIKit

enum Ingredients{
    case Bread
    case Cheese
    case Ham
    case Fruit
    case Egg
}
 
var HowToStartSW = Ingredients.Bread

switch HowToStartSW {
case.Bread:
    print("First we will choose what bread we will use! I think I'll use toasted white bread for this one!")
case .Cheese:
    print("First, I think we should start our sandwhich with cheese!")
case .Ham:
    print("We should start off with the ham for our sandwhich first!")
case .Fruit:
    print("I say we start off with our fruits of the sandwhich first!")
case .Egg:
    print("I say we should work on the egg of the sandwhich to start everything off!")
}
var SecondStep = Ingredients.Egg
switch SecondStep{
case .Bread:
    print("Silly me! Why would I need more bread!")
case .Cheese:
    print("Since the bread is toasting we should get our slice of cheese out the fridge!")
case .Ham:
    print("Since the bread is toasting we should get the ham out the fridge next!")
case .Fruit:
    print("While we wait for the bread to toast we should prepare our tomato and avacado!")
case .Egg:
    print("Secondly, It would be more ideal to make our egg before the bread is done toasting!")
    
}
var ThirdStep = Ingredients.Fruit
switch ThirdStep{
    
case .Bread:
    print("Silly me! Why would I need more bread!")
case .Cheese:
    print("Now that the egg is cooking and the bread is toasting, we should get our slice of cheese ready!")
case .Ham:
    print("Now that the egg is cooking and the bread is toasting, we should get our slice of ham ready!")
case .Fruit:
    print("Now that the egg is cooking and the bread is toasting, we should get our slices of tomato and avacado ready!")
case .Egg:
    print("We could make one more egg, but for this one I think I'll pass!")
}
var FourthStep = Ingredients.Ham
switch FourthStep{
    
case .Bread:
    print("I dunno why I keep thinking we need more bread!!!")
case .Cheese:
    print("Now that we knocked off the most ardous tasks of making a sandwhich, we should get our slice of cheese!!")
case .Ham:
    print("Now that we knocked off the most ardous tasks of making a sandwhich, we should get our slice of ham!!")
case .Fruit:
    print("I do not want extra tomato or avacado in my sandwhich, so I'll pass")
case .Egg:
    print("We could make one more egg, but for this one I think I'll pass!")

}
var FinalStep = Ingredients.Cheese
switch FinalStep{
    
case .Bread:
    print("I dunno why I keep thinking we need more bread!!!")
case .Cheese:
    print("And last but not least! We just have to take out our slice of cheese and slap all of the ingredients together!!")
case .Ham:
    print("Not necessary ")
case .Fruit:
    print("Not necessary")
case .Egg:
    print("Not necessary")

}
print("Now that you know how to make a delicious sandwhich, make sure to like and subscribe to my channel for more content! This has been cooking with Delgado, see you next time!!")
